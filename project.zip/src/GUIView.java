import java.util.List;

public interface GUIView {
    void update(List<SearchResult> results);
}
